﻿namespace TicketingSysteem.Entities.Enums
{
    public enum Rol
    {
        Gebruiker,
        Manager,
        Dispatcher,
        Solver,
        Administrator
    }
}
