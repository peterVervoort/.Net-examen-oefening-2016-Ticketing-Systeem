﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TicketingSysteem.Entities.PocoFactory.FactoryUsedEnums
{
    public enum Voornaam
    {
        Jan,
        Piet,
        Pol,
        Mieke,
        Ilse
    }
}
