﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TicketingSysteem.Entities.PocoFactory.FactoryUsedEnums
{
    public enum IssueTitel
    {
        EenTitel,
        NogEenTitel,
        volgendeTitel,
        DeTitelErna,
        BijnaLaatsteTitel
    }
}
