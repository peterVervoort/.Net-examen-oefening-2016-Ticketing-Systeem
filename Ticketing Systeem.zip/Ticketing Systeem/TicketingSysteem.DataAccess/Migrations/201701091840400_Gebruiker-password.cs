namespace TicketingSysteem.DataAccess.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Gebruikerpassword : DbMigration
    {
        public override void Up()
        {
            DropColumn("dbo.Gebruiker", "Paswoord");
        }
        
        public override void Down()
        {
            AddColumn("dbo.Gebruiker", "Paswoord", c => c.String(nullable: false));
        }
    }
}
